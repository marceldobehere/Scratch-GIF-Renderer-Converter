﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace GIF_to_Scratch_Video_Player
{
    class Program
    {
        public static Bitmap[] GetFramesFromAnimatedGIF(Image IMG)
        {
            res.x = IMG.Width;
            res.y = IMG.Height;
            List<Bitmap> IMGs = new List<Bitmap>();
            IMGs.Add(new Bitmap(res.x, res.y));
            int Length = IMG.GetFrameCount(FrameDimension.Time);

            for (int i = 0; i < Length; i++)
            {
                IMG.SelectActiveFrame(FrameDimension.Time, i);
                IMGs.Add(new Bitmap(IMG));
            }
            IMGs.Add(new Bitmap(IMGs[1]));
            return IMGs.ToArray();
        }

        public static (int x, int y) res;

        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                if (args[0].EndsWith(".gif"))
                {
                    Bitmap[] imgarr = GetFramesFromAnimatedGIF(Image.FromFile(args[0]));

                    using (StreamWriter writer = new StreamWriter("out.txt"))
                    {
                        writer.WriteLine($"RES {res.x} {res.y}");
                        for (int index = 1; index < imgarr.Length; index++)
                        {
                            List<(int x, int y, Color newcol)> Updates = new List<(int x, int y, Color newcol)>();
                            for (int y = 0; y < res.y; y++)
                            {
                                for (int x = 0; x < res.x; x++)
                                {
                                    if (imgarr[index - 1].GetPixel(x, y) != imgarr[index].GetPixel(x, y))
                                    {
                                        Updates.Add((x, y, imgarr[index].GetPixel(x, y)));

                                    }
                                }
                            }

                            Dictionary<Color, Dictionary<int, List<int>>> ColUpdatesX = new Dictionary<Color, Dictionary<int, List<int>>>();

                            for (int i = 0; i < Updates.Count; i++)
                            {
                                if (ColUpdatesX.ContainsKey(Updates[i].newcol))
                                {
                                    if (ColUpdatesX[Updates[i].newcol].ContainsKey(Updates[i].x))
                                    {
                                        if (ColUpdatesX[Updates[i].newcol][Updates[i].x].Contains(Updates[i].y))
                                        {
                                            Console.WriteLine("ERROR!");
                                        }
                                        else
                                        {
                                            ColUpdatesX[Updates[i].newcol][Updates[i].x].Add(Updates[i].y);
                                        }
                                    }
                                    else
                                    {
                                        ColUpdatesX[Updates[i].newcol].Add(Updates[i].x, new List<int>() { Updates[i].y });
                                    }
                                }
                                else
                                {
                                    ColUpdatesX.Add(Updates[i].newcol, new Dictionary<int, List<int>>() { { Updates[i].x, new List<int>() { Updates[i].y } } });
                                }
                            }


                            Dictionary<Color, Dictionary<int, List<int>>> ColUpdatesY = new Dictionary<Color, Dictionary<int, List<int>>>();

                            for (int i = 0; i < Updates.Count; i++)
                            {
                                if (ColUpdatesY.ContainsKey(Updates[i].newcol))
                                {
                                    if (ColUpdatesY[Updates[i].newcol].ContainsKey(Updates[i].y))
                                    {
                                        if (ColUpdatesY[Updates[i].newcol][Updates[i].y].Contains(Updates[i].x))
                                        {
                                            Console.WriteLine("ERROR!");
                                        }
                                        else
                                        {
                                            ColUpdatesY[Updates[i].newcol][Updates[i].y].Add(Updates[i].x);
                                        }
                                    }
                                    else
                                    {
                                        ColUpdatesY[Updates[i].newcol].Add(Updates[i].y, new List<int>() { Updates[i].x });
                                    }
                                }
                                else
                                {
                                    ColUpdatesY.Add(Updates[i].newcol, new Dictionary<int, List<int>>() { { Updates[i].y, new List<int>() { Updates[i].x } } });
                                }
                            }
                            
                            if (ColUpdatesX.Count < ColUpdatesY.Count)
                            {

                                Console.WriteLine("Writing Data... (X)");
                                writer.WriteLine("F");
                                for (int i = 0; i < ColUpdatesX.Count; i++)
                                {
                                    KeyValuePair<Color, Dictionary<int, List<int>>> il = ColUpdatesX.ElementAt(i);
                                    writer.WriteLine($"C {(il.Key.B + (il.Key.G * 256) + (il.Key.R * 256 * 256))}");
                                    //Console.WriteLine($"Col: {(il.Key.B + (il.Key.G * 256) + (il.Key.R * 256 * 256))}");
                                    for (int i2 = 0; i2 < il.Value.Count; i2++)
                                    {
                                        KeyValuePair<int, List<int>> i2l = il.Value.ElementAt(i2);
                                        writer.Write($" X {i2l.Key}");
                                        for (int i3 = 0; i3 < i2l.Value.Count; i3++)
                                        {
                                            writer.Write($" {i2l.Value[i3]}");
                                        }
                                    }
                                    writer.WriteLine();
                                }
                            }
                            else
                            {

                                Console.WriteLine("Writing Data... (Y)");
                                writer.WriteLine("F");
                                for (int i = 0; i < ColUpdatesY.Count; i++)
                                {
                                    KeyValuePair<Color, Dictionary<int, List<int>>> il = ColUpdatesY.ElementAt(i);
                                    writer.Write($"C {(il.Key.B + (il.Key.G * 256) + (il.Key.R * 256 * 256))}");
                                    //Console.WriteLine($"Col: {(il.Key.B + (il.Key.G * 256) + (il.Key.R * 256 * 256))}");
                                    for (int i2 = 0; i2 < il.Value.Count; i2++)
                                    {
                                        KeyValuePair<int, List<int>> i2l = il.Value.ElementAt(i2);
                                        writer.Write($" Y {i2l.Key}");
                                        for (int i3 = 0; i3 < i2l.Value.Count; i3++)

                                        {
                                            writer.Write($" {i2l.Value[i3]}");
                                        }
                                    }
                                    writer.WriteLine();
                                }
                            }




                        }
                    }

                        











                }
                else
                {
                    Console.WriteLine("Invalid File opened with.");
                }
            }
            else
            {
                Console.WriteLine("No File opened with.");
            }



            Console.WriteLine("\nEnd.");
            Console.ReadLine();
        }
    }
}
